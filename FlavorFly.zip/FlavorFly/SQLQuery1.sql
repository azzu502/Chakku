﻿insert into UserInfo values ('Mahmud', 'pass1234', 'Dhaka', '01838019362', 'Sector-11, Uttara');
insert into UserInfo values ('Abrar', 'word1234', 'Dhaka', '01838018888', 'Sector-10, Uttara');
insert into UserInfo values ('Rupam', 'pass4321', 'Dhaka', '01838019999', 'Sector-9, Uttara');
insert into UserInfo values ('Rifat', 'word4321', 'Dhaka', '01838012222', 'Sector-7, Uttara');


select*
from UserInfo;




insert into AdminInfo values ('Sajjad', '1234', 'Chakri Pabona');
insert into AdminInfo values ('Abrar', '1234', 'Elvish Bhai');
insert into AdminInfo values ('Rupam', '1234', 'Ruippa');
insert into AdminInfo values ('Rifat', '1234', 'Boro Bhai');


select*
from AdminInfo;