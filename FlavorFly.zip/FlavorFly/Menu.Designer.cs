﻿namespace FlavorFly
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            pictureBox3 = new PictureBox();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            panel2 = new Panel();
            pictureBox2 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            numericUpDown1 = new NumericUpDown();
            numericUpDown2 = new NumericUpDown();
            numericUpDown3 = new NumericUpDown();
            numericUpDown4 = new NumericUpDown();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            ReviewBtn = new Button();
            button1 = new Button();
            button2 = new Button();
            ReturnBtn = new Button();
            panel3 = new Panel();
            button3 = new Button();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            numericUpDown6 = new NumericUpDown();
            numericUpDown7 = new NumericUpDown();
            numericUpDown8 = new NumericUpDown();
            pictureBox8 = new PictureBox();
            pictureBox9 = new PictureBox();
            pictureBox10 = new PictureBox();
            panel4 = new Panel();
            button5 = new Button();
            label18 = new Label();
            label19 = new Label();
            numericUpDown13 = new NumericUpDown();
            numericUpDown14 = new NumericUpDown();
            pictureBox15 = new PictureBox();
            pictureBox16 = new PictureBox();
            panel5 = new Panel();
            button7 = new Button();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            label23 = new Label();
            numericUpDown15 = new NumericUpDown();
            numericUpDown16 = new NumericUpDown();
            numericUpDown17 = new NumericUpDown();
            numericUpDown18 = new NumericUpDown();
            pictureBox17 = new PictureBox();
            pictureBox18 = new PictureBox();
            pictureBox19 = new PictureBox();
            pictureBox20 = new PictureBox();
            pictureBox13 = new PictureBox();
            pictureBox12 = new PictureBox();
            pictureBox11 = new PictureBox();
            pictureBox7 = new PictureBox();
            numericUpDown11 = new NumericUpDown();
            numericUpDown10 = new NumericUpDown();
            numericUpDown9 = new NumericUpDown();
            numericUpDown5 = new NumericUpDown();
            label16 = new Label();
            label15 = new Label();
            label14 = new Label();
            label10 = new Label();
            button4 = new Button();
            panel6 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown4).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).BeginInit();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown5).BeginInit();
            panel6.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.wall;
            pictureBox3.Location = new Point(1, 1);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(144, 211);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 9;
            pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.wall;
            pictureBox1.Location = new Point(1, 207);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(144, 244);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(142, 1);
            panel1.Name = "panel1";
            panel1.Size = new Size(655, 453);
            panel1.TabIndex = 10;
            panel1.Paint += panel1_Paint;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Orange;
            label5.BorderStyle = BorderStyle.FixedSingle;
            label5.Font = new Font("Segoe UI Emoji", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(542, 0);
            label5.Name = "label5";
            label5.Size = new Size(104, 34);
            label5.TabIndex = 4;
            label5.Text = "DRINKS";
            label5.Click += label5_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.NavajoWhite;
            label4.BorderStyle = BorderStyle.FixedSingle;
            label4.FlatStyle = FlatStyle.Flat;
            label4.Font = new Font("Segoe UI Emoji", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(389, 0);
            label4.Name = "label4";
            label4.Size = new Size(147, 34);
            label4.TabIndex = 3;
            label4.Text = " DESSERTS ";
            label4.Click += label4_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Orange;
            label3.BorderStyle = BorderStyle.FixedSingle;
            label3.Font = new Font("Segoe UI Emoji", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(257, 0);
            label3.Name = "label3";
            label3.Size = new Size(126, 34);
            label3.TabIndex = 2;
            label3.Text = "  MEALS  ";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.NavajoWhite;
            label2.BorderStyle = BorderStyle.FixedSingle;
            label2.Font = new Font("Segoe UI Emoji", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ImageAlign = ContentAlignment.BottomLeft;
            label2.Location = new Point(137, 0);
            label2.Name = "label2";
            label2.Size = new Size(115, 34);
            label2.TabIndex = 1;
            label2.Text = "  PIZZA  ";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Orange;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Segoe UI Emoji", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(9, 0);
            label1.Name = "label1";
            label1.Size = new Size(122, 34);
            label1.TabIndex = 0;
            label1.Text = "BURGERS";
            label1.Click += label1_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Orange;
            panel2.Controls.Add(ReviewBtn);
            panel2.Controls.Add(label9);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(label7);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(numericUpDown4);
            panel2.Controls.Add(numericUpDown3);
            panel2.Controls.Add(numericUpDown2);
            panel2.Controls.Add(numericUpDown1);
            panel2.Controls.Add(pictureBox5);
            panel2.Controls.Add(pictureBox6);
            panel2.Controls.Add(pictureBox4);
            panel2.Controls.Add(pictureBox2);
            panel2.Location = new Point(9, 37);
            panel2.Name = "panel2";
            panel2.Size = new Size(637, 413);
            panel2.TabIndex = 5;
            panel2.Paint += panel2_Paint;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.bbc;
            pictureBox2.Location = new Point(24, 27);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(162, 147);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.bcc;
            pictureBox4.Location = new Point(322, 27);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(152, 147);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 1;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = Properties.Resources.bmc;
            pictureBox5.Location = new Point(322, 232);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(152, 139);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 3;
            pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = Properties.Resources.bcs;
            pictureBox6.Location = new Point(24, 232);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(162, 139);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 2;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(47, 190);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(120, 23);
            numericUpDown1.TabIndex = 4;
            numericUpDown1.ValueChanged += numericUpDown1_ValueChanged;
            // 
            // numericUpDown2
            // 
            numericUpDown2.Location = new Point(338, 190);
            numericUpDown2.Name = "numericUpDown2";
            numericUpDown2.Size = new Size(120, 23);
            numericUpDown2.TabIndex = 5;
            // 
            // numericUpDown3
            // 
            numericUpDown3.Location = new Point(47, 384);
            numericUpDown3.Name = "numericUpDown3";
            numericUpDown3.Size = new Size(120, 23);
            numericUpDown3.TabIndex = 6;
            // 
            // numericUpDown4
            // 
            numericUpDown4.Location = new Point(338, 384);
            numericUpDown4.Name = "numericUpDown4";
            numericUpDown4.Size = new Size(120, 23);
            numericUpDown4.TabIndex = 7;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(192, 27);
            label6.Name = "label6";
            label6.Size = new Size(112, 84);
            label6.TabIndex = 8;
            label6.Text = "BEEF CHEESE\r\nDELIGHT\r\n  \r\nTK.  240 ";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(480, 27);
            label7.Name = "label7";
            label7.Size = new Size(86, 105);
            label7.TabIndex = 9;
            label7.Text = "CHICKEN \r\nCHEESE\r\nDELIGHT\r\n\r\nTK.  240 ";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(192, 232);
            label8.Name = "label8";
            label8.Size = new Size(86, 84);
            label8.TabIndex = 10;
            label8.Text = "CHICKEN \r\nSUPREME\r\n  \r\nTK.  350";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(480, 232);
            label9.Name = "label9";
            label9.Size = new Size(116, 84);
            label9.TabIndex = 11;
            label9.Text = "MUSHROOM \r\nCARAMEL\r\n  \r\nTK.  370";
            // 
            // ReviewBtn
            // 
            ReviewBtn.BackColor = Color.FromArgb(128, 128, 255);
            ReviewBtn.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ReviewBtn.Location = new Point(490, 355);
            ReviewBtn.Name = "ReviewBtn";
            ReviewBtn.Size = new Size(134, 45);
            ReviewBtn.TabIndex = 11;
            ReviewBtn.Text = "ORDER\r\n";
            ReviewBtn.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.BackColor = Color.Orange;
            button1.Font = new Font("Segoe UI Emoji", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(1, 228);
            button1.Name = "button1";
            button1.Size = new Size(144, 45);
            button1.TabIndex = 11;
            button1.Text = "CHECKOUT";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.Orange;
            button2.Font = new Font("Segoe UI Emoji", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(1, 167);
            button2.Name = "button2";
            button2.Size = new Size(144, 45);
            button2.TabIndex = 12;
            button2.Text = "CART";
            button2.UseVisualStyleBackColor = false;
            // 
            // ReturnBtn
            // 
            ReturnBtn.BackColor = Color.IndianRed;
            ReturnBtn.Font = new Font("Segoe UI Emoji", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ReturnBtn.Location = new Point(26, 365);
            ReturnBtn.Name = "ReturnBtn";
            ReturnBtn.Size = new Size(82, 29);
            ReturnBtn.TabIndex = 28;
            ReturnBtn.Text = "Return";
            ReturnBtn.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            panel3.BackColor = Color.NavajoWhite;
            panel3.Controls.Add(panel5);
            panel3.Controls.Add(panel4);
            panel3.Controls.Add(button3);
            panel3.Controls.Add(label11);
            panel3.Controls.Add(label12);
            panel3.Controls.Add(label13);
            panel3.Controls.Add(numericUpDown6);
            panel3.Controls.Add(numericUpDown7);
            panel3.Controls.Add(numericUpDown8);
            panel3.Controls.Add(pictureBox8);
            panel3.Controls.Add(pictureBox9);
            panel3.Controls.Add(pictureBox10);
            panel3.Location = new Point(9, 37);
            panel3.Name = "panel3";
            panel3.Size = new Size(637, 413);
            panel3.TabIndex = 12;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(128, 128, 255);
            button3.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(490, 355);
            button3.Name = "button3";
            button3.Size = new Size(134, 45);
            button3.TabIndex = 11;
            button3.Text = "ORDER\r\n";
            button3.UseVisualStyleBackColor = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.Location = new Point(322, 232);
            label11.Name = "label11";
            label11.Size = new Size(85, 63);
            label11.TabIndex = 10;
            label11.Text = "BBQ BEEF\r\n(9\")\r\nTK.  480\r\n";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(480, 27);
            label12.Name = "label12";
            label12.Size = new Size(100, 63);
            label12.TabIndex = 9;
            label12.Text = "BEEF CORN\r\n(9\")\r\nTK.  420\r\n";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(192, 27);
            label13.Name = "label13";
            label13.Size = new Size(111, 63);
            label13.TabIndex = 8;
            label13.Text = "BEEF MAYO  \r\n(9\")\r\nTK.  460\r\n";
            // 
            // numericUpDown6
            // 
            numericUpDown6.Location = new Point(177, 384);
            numericUpDown6.Name = "numericUpDown6";
            numericUpDown6.Size = new Size(120, 23);
            numericUpDown6.TabIndex = 6;
            // 
            // numericUpDown7
            // 
            numericUpDown7.Location = new Point(338, 190);
            numericUpDown7.Name = "numericUpDown7";
            numericUpDown7.Size = new Size(120, 23);
            numericUpDown7.TabIndex = 5;
            // 
            // numericUpDown8
            // 
            numericUpDown8.Location = new Point(47, 190);
            numericUpDown8.Name = "numericUpDown8";
            numericUpDown8.Size = new Size(120, 23);
            numericUpDown8.TabIndex = 4;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = Properties.Resources.pbb;
            pictureBox8.Location = new Point(154, 232);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(162, 139);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 2;
            pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = Properties.Resources.pbc;
            pictureBox9.Location = new Point(322, 27);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(152, 147);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 1;
            pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = Properties.Resources.pbm;
            pictureBox10.Location = new Point(24, 27);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(162, 147);
            pictureBox10.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox10.TabIndex = 0;
            pictureBox10.TabStop = false;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Orange;
            panel4.Controls.Add(button5);
            panel4.Controls.Add(label18);
            panel4.Controls.Add(label19);
            panel4.Controls.Add(numericUpDown13);
            panel4.Controls.Add(numericUpDown14);
            panel4.Controls.Add(pictureBox15);
            panel4.Controls.Add(pictureBox16);
            panel4.Location = new Point(0, 3);
            panel4.Name = "panel4";
            panel4.Size = new Size(637, 413);
            panel4.TabIndex = 12;
            panel4.Paint += panel4_Paint;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(128, 128, 255);
            button5.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.Location = new Point(490, 355);
            button5.Name = "button5";
            button5.Size = new Size(134, 45);
            button5.TabIndex = 11;
            button5.Text = "ORDER\r\n";
            button5.UseVisualStyleBackColor = false;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label18.Location = new Point(372, 273);
            label18.Name = "label18";
            label18.Size = new Size(229, 42);
            label18.TabIndex = 9;
            label18.Text = "MEAL-2(MUTTON BIRIYANI)\r\n               TK. 450";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label19.Location = new Point(64, 266);
            label19.Name = "label19";
            label19.Size = new Size(170, 42);
            label19.TabIndex = 8;
            label19.Text = "MEAL-1(FRIED RICE)\r\n         TK.  380";
            // 
            // numericUpDown13
            // 
            numericUpDown13.Location = new Point(428, 324);
            numericUpDown13.Name = "numericUpDown13";
            numericUpDown13.Size = new Size(120, 23);
            numericUpDown13.TabIndex = 5;
            // 
            // numericUpDown14
            // 
            numericUpDown14.Location = new Point(89, 324);
            numericUpDown14.Name = "numericUpDown14";
            numericUpDown14.Size = new Size(120, 23);
            numericUpDown14.TabIndex = 4;
            // 
            // pictureBox15
            // 
            pictureBox15.Image = Properties.Resources.mb;
            pictureBox15.Location = new Point(356, 24);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new Size(256, 239);
            pictureBox15.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox15.TabIndex = 1;
            pictureBox15.TabStop = false;
            // 
            // pictureBox16
            // 
            pictureBox16.Image = Properties.Resources.sm;
            pictureBox16.Location = new Point(24, 27);
            pictureBox16.Name = "pictureBox16";
            pictureBox16.Size = new Size(254, 236);
            pictureBox16.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox16.TabIndex = 0;
            pictureBox16.TabStop = false;
            // 
            // panel5
            // 
            panel5.BackColor = Color.NavajoWhite;
            panel5.Controls.Add(panel6);
            panel5.Controls.Add(button7);
            panel5.Controls.Add(label20);
            panel5.Controls.Add(label21);
            panel5.Controls.Add(label22);
            panel5.Controls.Add(label23);
            panel5.Controls.Add(numericUpDown15);
            panel5.Controls.Add(numericUpDown16);
            panel5.Controls.Add(numericUpDown17);
            panel5.Controls.Add(numericUpDown18);
            panel5.Controls.Add(pictureBox17);
            panel5.Controls.Add(pictureBox18);
            panel5.Controls.Add(pictureBox19);
            panel5.Controls.Add(pictureBox20);
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(637, 413);
            panel5.TabIndex = 12;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(128, 128, 255);
            button7.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button7.Location = new Point(490, 355);
            button7.Name = "button7";
            button7.Size = new Size(134, 45);
            button7.TabIndex = 11;
            button7.Text = "ORDER\r\n";
            button7.UseVisualStyleBackColor = false;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label20.Location = new Point(480, 232);
            label20.Name = "label20";
            label20.Size = new Size(108, 84);
            label20.TabIndex = 11;
            label20.Text = "CHOCOLATE\r\nMOUSSE\r\n  \r\nTK.  200\r\n";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label21.Location = new Point(192, 232);
            label21.Name = "label21";
            label21.Size = new Size(118, 126);
            label21.TabIndex = 10;
            label21.Text = "STRAWBERRY\r\nALMOND\r\nMILK \r\nPUDDING\r\n\r\nTK.  200";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label22.Location = new Point(480, 27);
            label22.Name = "label22";
            label22.Size = new Size(86, 84);
            label22.TabIndex = 9;
            label22.Text = "DRY\r\nKALOJAM\r\n\r\nTK.  200\r\n";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label23.Location = new Point(192, 27);
            label23.Name = "label23";
            label23.Size = new Size(83, 105);
            label23.TabIndex = 8;
            label23.Text = "DUTCH \r\nTRUFFLE \r\nPASTRY\r\n  \r\nTK.  200";
            // 
            // numericUpDown15
            // 
            numericUpDown15.Location = new Point(338, 384);
            numericUpDown15.Name = "numericUpDown15";
            numericUpDown15.Size = new Size(120, 23);
            numericUpDown15.TabIndex = 7;
            // 
            // numericUpDown16
            // 
            numericUpDown16.Location = new Point(47, 384);
            numericUpDown16.Name = "numericUpDown16";
            numericUpDown16.Size = new Size(120, 23);
            numericUpDown16.TabIndex = 6;
            // 
            // numericUpDown17
            // 
            numericUpDown17.Location = new Point(338, 190);
            numericUpDown17.Name = "numericUpDown17";
            numericUpDown17.Size = new Size(120, 23);
            numericUpDown17.TabIndex = 5;
            // 
            // numericUpDown18
            // 
            numericUpDown18.Location = new Point(47, 190);
            numericUpDown18.Name = "numericUpDown18";
            numericUpDown18.Size = new Size(120, 23);
            numericUpDown18.TabIndex = 4;
            // 
            // pictureBox17
            // 
            pictureBox17.Image = Properties.Resources.cm;
            pictureBox17.Location = new Point(322, 232);
            pictureBox17.Name = "pictureBox17";
            pictureBox17.Size = new Size(152, 139);
            pictureBox17.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox17.TabIndex = 3;
            pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            pictureBox18.Image = Properties.Resources.samp;
            pictureBox18.Location = new Point(24, 232);
            pictureBox18.Name = "pictureBox18";
            pictureBox18.Size = new Size(162, 139);
            pictureBox18.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox18.TabIndex = 2;
            pictureBox18.TabStop = false;
            // 
            // pictureBox19
            // 
            pictureBox19.Image = Properties.Resources.kj;
            pictureBox19.Location = new Point(322, 27);
            pictureBox19.Name = "pictureBox19";
            pictureBox19.Size = new Size(152, 147);
            pictureBox19.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox19.TabIndex = 1;
            pictureBox19.TabStop = false;
            // 
            // pictureBox20
            // 
            pictureBox20.Image = Properties.Resources.cp;
            pictureBox20.Location = new Point(24, 27);
            pictureBox20.Name = "pictureBox20";
            pictureBox20.Size = new Size(162, 147);
            pictureBox20.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox20.TabIndex = 0;
            pictureBox20.TabStop = false;
            // 
            // pictureBox13
            // 
            pictureBox13.Image = Properties.Resources.l;
            pictureBox13.Location = new Point(24, 27);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(162, 147);
            pictureBox13.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox13.TabIndex = 0;
            pictureBox13.TabStop = false;
            // 
            // pictureBox12
            // 
            pictureBox12.Image = Properties.Resources.cc;
            pictureBox12.Location = new Point(322, 27);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(152, 147);
            pictureBox12.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox12.TabIndex = 1;
            pictureBox12.TabStop = false;
            // 
            // pictureBox11
            // 
            pictureBox11.Image = Properties.Resources.sms;
            pictureBox11.Location = new Point(24, 232);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(162, 139);
            pictureBox11.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox11.TabIndex = 2;
            pictureBox11.TabStop = false;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = Properties.Resources.ncc;
            pictureBox7.Location = new Point(322, 232);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(152, 139);
            pictureBox7.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox7.TabIndex = 3;
            pictureBox7.TabStop = false;
            // 
            // numericUpDown11
            // 
            numericUpDown11.Location = new Point(47, 190);
            numericUpDown11.Name = "numericUpDown11";
            numericUpDown11.Size = new Size(120, 23);
            numericUpDown11.TabIndex = 4;
            // 
            // numericUpDown10
            // 
            numericUpDown10.Location = new Point(338, 190);
            numericUpDown10.Name = "numericUpDown10";
            numericUpDown10.Size = new Size(120, 23);
            numericUpDown10.TabIndex = 5;
            // 
            // numericUpDown9
            // 
            numericUpDown9.Location = new Point(47, 384);
            numericUpDown9.Name = "numericUpDown9";
            numericUpDown9.Size = new Size(120, 23);
            numericUpDown9.TabIndex = 6;
            // 
            // numericUpDown5
            // 
            numericUpDown5.Location = new Point(338, 384);
            numericUpDown5.Name = "numericUpDown5";
            numericUpDown5.Size = new Size(120, 23);
            numericUpDown5.TabIndex = 7;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.Location = new Point(192, 69);
            label16.Name = "label16";
            label16.Size = new Size(101, 42);
            label16.TabIndex = 8;
            label16.Text = "LEMONADE\r\nTK.  70";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.Location = new Point(480, 69);
            label15.Name = "label15";
            label15.Size = new Size(70, 63);
            label15.TabIndex = 9;
            label15.Text = "COLD\r\nCOFFEE\r\nTK. 120\r\n";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.Location = new Point(192, 232);
            label14.Name = "label14";
            label14.Size = new Size(118, 63);
            label14.TabIndex = 10;
            label14.Text = "STRAWBERRY\r\nMILKSHAKE\r\nTK.  150";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(480, 232);
            label10.Name = "label10";
            label10.Size = new Size(120, 84);
            label10.TabIndex = 11;
            label10.Text = "NATURALLY\r\nCARBONATED\r\nSODA\r\nTK.  100\r\n";
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(128, 128, 255);
            button4.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(490, 355);
            button4.Name = "button4";
            button4.Size = new Size(134, 45);
            button4.TabIndex = 11;
            button4.Text = "ORDER\r\n";
            button4.UseVisualStyleBackColor = false;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Orange;
            panel6.Controls.Add(button4);
            panel6.Controls.Add(label10);
            panel6.Controls.Add(label14);
            panel6.Controls.Add(label15);
            panel6.Controls.Add(label16);
            panel6.Controls.Add(numericUpDown5);
            panel6.Controls.Add(numericUpDown9);
            panel6.Controls.Add(numericUpDown10);
            panel6.Controls.Add(numericUpDown11);
            panel6.Controls.Add(pictureBox7);
            panel6.Controls.Add(pictureBox11);
            panel6.Controls.Add(pictureBox12);
            panel6.Controls.Add(pictureBox13);
            panel6.Location = new Point(0, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(637, 413);
            panel6.TabIndex = 13;
            // 
            // Menu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(787, 451);
            Controls.Add(ReturnBtn);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(panel1);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Menu";
            Text = "Menu";
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown3).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown4).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown6).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown7).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown13).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown15).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown16).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown17).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown18).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox17).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox18).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox19).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox20).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown11).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown10).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown9).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown5).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox3;
        private PictureBox pictureBox1;
        private Panel panel1;
        private Label label1;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Panel panel2;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox4;
        private PictureBox pictureBox2;
        private NumericUpDown numericUpDown1;
        private Label label6;
        private NumericUpDown numericUpDown4;
        private NumericUpDown numericUpDown3;
        private NumericUpDown numericUpDown2;
        private Label label7;
        private Label label9;
        private Label label8;
        private Button ReviewBtn;
        private Button button1;
        private Button button2;
        private Panel panel3;
        private Button button3;
        private Label label11;
        private Label label12;
        private Label label13;
        private NumericUpDown numericUpDown6;
        private NumericUpDown numericUpDown7;
        private NumericUpDown numericUpDown8;
        private PictureBox pictureBox8;
        private PictureBox pictureBox9;
        private PictureBox pictureBox10;
        private Button ReturnBtn;
        private Panel panel4;
        private Button button5;
        private Label label18;
        private Label label19;
        private NumericUpDown numericUpDown13;
        private NumericUpDown numericUpDown14;
        private PictureBox pictureBox15;
        private PictureBox pictureBox16;
        private Panel panel5;
        private Button button7;
        private Label label20;
        private Label label21;
        private Label label22;
        private Label label23;
        private NumericUpDown numericUpDown15;
        private NumericUpDown numericUpDown16;
        private NumericUpDown numericUpDown17;
        private NumericUpDown numericUpDown18;
        private PictureBox pictureBox17;
        private PictureBox pictureBox18;
        private PictureBox pictureBox19;
        private PictureBox pictureBox20;
        private Panel panel6;
        private Button button4;
        private Label label10;
        private Label label14;
        private Label label15;
        private Label label16;
        private NumericUpDown numericUpDown5;
        private NumericUpDown numericUpDown9;
        private NumericUpDown numericUpDown10;
        private NumericUpDown numericUpDown11;
        private PictureBox pictureBox7;
        private PictureBox pictureBox11;
        private PictureBox pictureBox12;
        private PictureBox pictureBox13;
    }
}